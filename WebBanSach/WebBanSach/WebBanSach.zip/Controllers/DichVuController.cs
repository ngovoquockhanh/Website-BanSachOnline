﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebBanSach.Controllers
{
    public class DichVuController : Controller
    {
        // GET: DichVu
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult BaoMat()
        {
            return View();
        }
        public ActionResult HoTro()
        {
            return View();
        }
        public ActionResult VanChuyen()
        {
            return View();
        }

    }
}